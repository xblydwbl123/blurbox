# BlurBox · 安卓内嵌视频播放器（全程模糊 + 防截屏）

一个可直接用 Android Studio 打开的完整安卓工程：

- **内嵌视频**：`assets/demo.mp4` 随包内置，打开即循环播放；也可用「选择本地视频」载入任意视频。
- **全程自动变糊**：视频帧经过 OpenGL ES 两趟高斯模糊后才上屏，播放期间**始终**是模糊画面，不是截图时才盖一层蒙版。
- **防截屏**：`FLAG_SECURE` 常开 + 切后台实色遮罩，拦截系统截屏、录屏、最近任务预览。

效果对照见随包交付的 `VideoBlur_效果预览.png`。

---

## 1. 跑起来

1. 解压 `VideoBlurAndroid.zip`，用 **Android Studio 2025 年之后的版本（Narwhal / Quail 均可）** 打开 `VideoBlurAndroid` 目录。
2. 等待 Gradle Sync 自动下载依赖（首次需要联网）。
3. 连接安卓手机（Android 7.0 / API 24 以上）或启动模拟器，点 **Run ▶**。
4. 命令行构建：先执行 `gradle wrapper --gradle-version 8.13` 生成 wrapper，再 `./gradlew assembleDebug`，产物在 `app/build/outputs/apk/debug/app-debug.apk`。

> 源码包里**没有** `gradle-wrapper.jar`（二进制不便随源码分发），已提供 `gradle/wrapper/gradle-wrapper.properties`。
> Android Studio 打开项目时会自动补齐 wrapper；这一步不影响 Sync 和编译。

## 2. 版本基线

| 组件 | 版本 |
| --- | --- |
| AGP / Gradle | 8.11.1 / 8.13 |
| Kotlin 插件 | 2.2.21 |
| compileSdk / targetSdk / minSdk | 36 / 36 / 24 |
| JDK | 17 |
| Media3 ExoPlayer | 1.5.1（稳定基线） |
| androidx core / activity | 1.16.0 / 1.10.1 |

AGP 8.x 仍需显式声明 `org.jetbrains.kotlin.android` 插件（AGP 9.x 才内置 Kotlin，届时不要重复声明）。
Media3 刻意锁定 1.5.1：播放 API 与 1.11.x 一致，但不会要求更高的 `compileSdk`。装了 SDK Platform 37 后，把 `app/build.gradle.kts` 里两行 media3 依赖一起改成 `1.11.1` 即可升级。

## 3. 目录结构

```
VideoBlurAndroid/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts / proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/demo.mp4              # 内置示例视频（8s / 540×960 / H.264 Baseline）
        ├── res/                         # layout / values / 各密度启动图标
        └── java/com/example/videoblur/
            ├── MainActivity.kt          # 窗口 flag、生命周期、ExoPlayer、交互
            └── gl/
                ├── GlProgram.kt         # GLSL 编译与 location 缓存
                ├── BlurRenderer.kt      # OES 纹理 + FBO ping-pong 两趟高斯
                └── BlurVideoSurfaceView.kt
```

## 4. 实现原理

### 全程模糊（核心）
```
ExoPlayer 解码 → SurfaceTexture(GL_TEXTURE_EXTERNAL_OES)
        ↓ 水平 5-tap 高斯 → FBO A（半分辨率）
        ↓ 垂直 5-tap 高斯 → FBO B
        ↓ 可重复 N 轮
        ↓ blit → 屏幕
```
- 用 `GLSurfaceView` 自绘，不依赖 `VideoView`，因此播放器输出的清晰帧**永远不会直接上屏**。
- FBO 固定为视图尺寸的 1/2，模糊更柔和且 GPU 开销更低；`RENDERMODE_WHEN_DIRTY` 只在视频新帧到达时绘制。
- 半分辨率 + 多轮迭代下，即使有人绕过 `FLAG_SECURE` 抓到帧缓冲，拿到的也仍是模糊像素。

### 防截屏
- `MainActivity.onCreate` 在 `setContentView` **之前**调用 `window.setFlags(FLAG_SECURE, FLAG_SECURE)`，并在 `onResume` 重新加固。
- 切到后台 / 失焦时叠加不透明遮罩并暂停播放，回到前台自动恢复。
- `AndroidManifest` 关闭 `allowBackup`，避免应用数据被备份导出。

### 视频源
- 内置：`asset:///demo.mp4`（media3 `DefaultDataSource` 原生支持）。
- 本地：系统文件选择器返回 `content://`，`takePersistableUriPermission` 后可重复读取。
- 换成网络流：`MediaItem.fromUri("https://...")` 即可，并在 Manifest 加 `INTERNET` 权限。

## 5. 可调参数

| 位置 | 参数 | 说明 |
| --- | --- | --- |
| 界面 | 模糊强度滑杆 | 0–24 px，0 为原画，默认 8 |
| `MainActivity.DEFAULT_ITERATIONS` | 迭代轮数 | 1–4，越大越糊，默认 2 |
| `BlurRenderer.FBO_SCALE` | 0.5 | 调小更糊更省电，调大更保细节 |
| `BlurRenderer.BLUR_FS_2D` | 权重 / 采样偏移 | 改 shader 可换模糊核、加暗角或水印 |
| `MainActivity.BUILT_IN_URI` | 内置视频路径 | 换成自己的 `assets/xxx.mp4` |

## 6. 防截屏能做到 / 做不到（务必看）

**能挡**：系统截屏与录屏、最近任务卡片缩略图、Google 助理屏幕搜索、多数投屏/无线显示、部分第三方截图工具。

**挡不住**：
- 用另一台设备**物理翻拍**屏幕；
- Root / Xposed / Hook 掉 `FLAG_SECURE` 或直接从 GL 读取纹理；
- 个别厂商自定义 ROM 的录屏实现、无障碍服务截图；
- 应用自身主动把视频帧导出（本工程的防护目标是「显示侧」）。

> 结论：`FLAG_SECURE` 是系统级防截屏的标准做法，但不是 DRM。真正敏感的内容应在服务端鉴权、使用 Widevine L1 DRM、叠加动态水印，并限制账号/设备。

## 7. 黑屏 / 播不了排查

1. **确认输出 Surface 已挂上**：GL 线程异步创建 `SurfaceTexture`，Activity 通过 `onSurfaceReady` 回调把 Surface 交给 ExoPlayer；两者谁先谁后都不影响，代码里做了双向兜底。
2. **确认视频编码**：安卓硬解支持 H.264 Baseline/Main + AAC；内置 `demo.mp4` 已按 H.264 Baseline / yuv420p 编码。换视频时优先用这个规格。
3. **确认设备支持 OES 扩展**：`GL_OES_EGL_image_external` 在 GLES2 设备上普遍可用；极老设备或模拟器软渲染可能失败，看 logcat 里 `GL shader compile failed`。
4. **确认没被遮罩盖住**：`screenShield` 只在 `onPause` 显示，若停留黑屏检查 Activity 生命周期是否异常。
5. 播放错误会直接显示在界面顶部状态行。

## 8. 交付说明

本工程是**完整源码**，交付环境不含 Android SDK 与真机，因此未做实机编译 / 运行验证；Gradle 配置与 API 按上表版本组合编写，用 Android Studio Sync 后即可编译。如需我针对你的 Android Studio 版本调整 AGP/Gradle 组合，或改成 Compose、横屏、加水印 / 截屏检测回调，可以继续说。
