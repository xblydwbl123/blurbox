package com.example.videoblur

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.videoblur.gl.BlurVideoSurfaceView

class MainActivity : ComponentActivity() {

    private lateinit var glVideo: BlurVideoSurfaceView
    private lateinit var tvStatus: TextView
    private lateinit var tvBlurValue: TextView
    private lateinit var seekBlur: SeekBar
    private lateinit var screenShield: View

    private var player: ExoPlayer? = null
    private var currentUri: Uri = Uri.parse(BUILT_IN_URI)

    private val pickVideo =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: SecurityException) {
                // 部分 ROM 不授予持久化权限，本次会话仍可正常读取
            }
            switchTo(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        // 关键：必须在 setContentView 之前设置。
        // FLAG_SECURE 由系统合成器层面生效，能挡住系统截屏、录屏、
        // 最近任务预览缩略图、Google 助理「屏幕搜索」等取屏行为。
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        glVideo = findViewById(R.id.glVideo)
        tvStatus = findViewById(R.id.tvStatus)
        tvBlurValue = findViewById(R.id.tvBlurValue)
        seekBlur = findViewById(R.id.seekBlur)
        screenShield = findViewById(R.id.screenShield)

        tvStatus.text = getString(R.string.status_secure)

        glVideo.onSurfaceReady = { attachVideoSurface() }
        glVideo.onSurfaceLost = { player?.setVideoSurface(null) }

        glVideo.blurPixels = DEFAULT_BLUR
        glVideo.blurIterations = DEFAULT_ITERATIONS
        seekBlur.progress = DEFAULT_BLUR.toInt()
        updateBlurLabel(DEFAULT_BLUR.toInt())

        seekBlur.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                glVideo.blurPixels = progress.toFloat()
                updateBlurLabel(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnPick).setOnClickListener {
            pickVideo.launch(arrayOf("video/*"))
        }
        findViewById<Button>(R.id.btnReset).setOnClickListener {
            switchTo(Uri.parse(BUILT_IN_URI))
        }
    }

    override fun onStart() {
        super.onStart()
        glVideo.onResume()
        createPlayer()
    }

    override fun onResume() {
        super.onResume()
        // 某些 ROM 在窗口重建后会清掉窗口 flag，回前台再加固一次
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        screenShield.visibility = View.GONE
        player?.play()
    }

    override fun onPause() {
        screenShield.visibility = View.VISIBLE
        player?.pause()
        super.onPause()
    }

    override fun onStop() {
        // 先摘 Surface 再释放播放器，避免向已失效的 Surface 继续出帧
        player?.setVideoSurface(null)
        player?.release()
        player = null
        glVideo.onPause()
        super.onStop()
    }

    private fun createPlayer() {
        if (player != null) return
        val exoPlayer = ExoPlayer.Builder(this).build()
        exoPlayer.repeatMode = Player.REPEAT_MODE_ALL
        exoPlayer.playWhenReady = true
        exoPlayer.setMediaItem(MediaItem.fromUri(currentUri))
        exoPlayer.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                tvStatus.text = "播放失败：${error.message ?: "未知错误"}（检查编码是否为 H.264/AAC）"
            }
        })
        player = exoPlayer
        attachVideoSurface()
        exoPlayer.prepare()
    }

    /** Surface 由 GL 线程异步创建；两边都就绪时才把它交给 ExoPlayer。 */
    private fun attachVideoSurface() {
        val surface = glVideo.currentSurface
        if (surface != null && surface.isValid) {
            player?.setVideoSurface(surface)
        }
    }

    private fun switchTo(uri: Uri) {
        currentUri = uri
        player?.let { p ->
            p.stop()
            p.setMediaItem(MediaItem.fromUri(uri))
            p.prepare()
            p.play()
        }
        val builtIn = uri.toString() == BUILT_IN_URI
        Toast.makeText(
            this,
            if (builtIn) "已恢复内置视频" else "已载入本地视频",
            Toast.LENGTH_SHORT
        ).show()
        tvStatus.text = getString(R.string.status_secure)
    }

    private fun updateBlurLabel(value: Int) {
        tvBlurValue.text = if (value == 0) "0 px（原画）" else "$value px"
    }

    private companion object {
        /** assets/demo.mp4；media3 的 DefaultDataSource 支持 asset:/// scheme */
        const val BUILT_IN_URI = "asset:///demo.mp4"
        const val DEFAULT_BLUR = 8f
        const val DEFAULT_ITERATIONS = 2
    }
}
