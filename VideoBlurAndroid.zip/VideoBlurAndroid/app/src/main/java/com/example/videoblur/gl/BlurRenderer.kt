package com.example.videoblur.gl

import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.Looper
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max

/**
 * 视频帧 -> OES 外部纹理 -> 半分辨率 FBO ping-pong 两趟高斯 -> 屏幕。
 *
 * 整条链路对每一帧都执行，因此「视频始终模糊」不是截图时才触发的遮罩，
 * 而是实际渲染出来的像素，任何取屏、录屏、投屏拿到的都是模糊画面。
 */
internal class BlurRenderer(
    private val glView: GLSurfaceView,
    private val onSurfaceReady: (Surface) -> Unit,
    private val onSurfaceLost: () -> Unit
) : GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {

    /** 高斯采样偏移（以 FBO 像素为单位）；0 = 原画，越大越糊。 */
    @Volatile
    var blurPixels: Float = 8f

    /** 水平 + 垂直各算一趟算 1 次迭代，范围 1..4。 */
    @Volatile
    var iterations: Int = 2

    /** 当前可供 ExoPlayer 输出的 Surface；EGL 重建时会替换为新对象。 */
    @Volatile
    var currentSurface: Surface? = null
        private set

    private val mainHandler = Handler(Looper.getMainLooper())
    private val stMatrix = FloatArray(16)
    private var oesTextureId = 0
    private var surfaceTexture: SurfaceTexture? = null

    private var texA = 0
    private var texB = 0
    private var fboA = 0
    private var fboB = 0
    private var fboWidth = 1
    private var fboHeight = 1
    private var viewWidth = 1
    private var viewHeight = 1

    private lateinit var progOesBlur: GlProgram
    private lateinit var progTexBlur: GlProgram
    private lateinit var progBlit: GlProgram

    // 全屏四边形：pos.xy + uv.xy，TRIANGLE_STRIP 绘制
    private val quad: FloatBuffer = ByteBuffer.allocateDirect(4 * 4 * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(
                floatArrayOf(
                    -1f, -1f, 0f, 0f,
                    1f, -1f, 1f, 0f,
                    -1f, 1f, 0f, 1f,
                    1f, 1f, 1f, 1f
                )
            )
            position(0)
        }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // EGL context 可能重建：旧 GL 对象随 context 失效，这里只重置句柄，
        // 并在 GL 线程里释放旧的 Surface / SurfaceTexture（Java 侧对象）。
        texA = 0; texB = 0; fboA = 0; fboB = 0
        releaseVideoSurfaceObjects()

        oesTextureId = createExternalTexture()
        val st = SurfaceTexture(oesTextureId)
        // GL 线程没有 Looper，显式把回调切到主线程；requestRender 可跨线程调用
        st.setOnFrameAvailableListener(this, mainHandler)
        surfaceTexture = st
        val surface = Surface(st)
        currentSurface = surface

        progOesBlur = GlProgram(VERTEX_SHADER, BLUR_FS_OES)
        progTexBlur = GlProgram(VERTEX_SHADER, BLUR_FS_2D)
        progBlit = GlProgram(VERTEX_SHADER, BLIT_FS)

        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glClearColor(0f, 0f, 0f, 1f)

        mainHandler.post {
            onSurfaceLost()          // 先摘掉旧的 Surface
            onSurfaceReady(surface)  // 再挂上新的
        }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewWidth = width
        viewHeight = height
        fboWidth = max(1, (width * FBO_SCALE).toInt())
        fboHeight = max(1, (height * FBO_SCALE).toInt())

        deleteFbos()
        texA = createColorTexture(fboWidth, fboHeight)
        texB = createColorTexture(fboWidth, fboHeight)
        fboA = createFramebuffer(texA)
        fboB = createFramebuffer(texB)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, width, height)
        glView.requestRender()
    }

    override fun onDrawFrame(gl: GL10?) {
        val st = surfaceTexture ?: return
        try {
            st.updateTexImage()
        } catch (e: RuntimeException) {
            // Surface 已释放 / 帧不可用，跳过这一帧
            return
        }
        st.getTransformMatrix(stMatrix)

        val rounds = iterations.coerceIn(1, 4)
        val radius = blurPixels.coerceAtLeast(0f)
        val hx = radius / fboWidth.toFloat()
        val vy = radius / fboHeight.toFloat()

        // 第 1 趟：外部纹理 -> 水平模糊 -> FBO A
        bindTarget(fboA, fboWidth, fboHeight)
        draw(progOesBlur, oesTextureId, stMatrix, hx, 0f, external = true)

        // 第 2 趟：A -> 垂直模糊 -> FBO B
        bindTarget(fboB, fboWidth, fboHeight)
        draw(progTexBlur, texA, IDENTITY_MATRIX, 0f, vy, external = false)

        // 追加迭代：多糊几轮，边缘更柔
        repeat(rounds - 1) {
            bindTarget(fboA, fboWidth, fboHeight)
            draw(progTexBlur, texB, IDENTITY_MATRIX, hx, 0f, external = false)
            bindTarget(fboB, fboWidth, fboHeight)
            draw(progTexBlur, texA, IDENTITY_MATRIX, 0f, vy, external = false)
        }

        // 最终合成到屏幕
        bindTarget(0, viewWidth, viewHeight)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        draw(progBlit, texB, IDENTITY_MATRIX, 0f, 0f, external = false)
    }

    override fun onFrameAvailable(surfaceTexture: SurfaceTexture?) {
        glView.requestRender()
    }

    private fun draw(
        program: GlProgram,
        textureId: Int,
        matrix: FloatArray,
        offX: Float,
        offY: Float,
        external: Boolean
    ) {
        program.use()

        quad.position(0)
        GLES20.glVertexAttribPointer(program.aPosition, 2, GLES20.GL_FLOAT, false, STRIDE, quad)
        GLES20.glEnableVertexAttribArray(program.aPosition)
        quad.position(2)
        GLES20.glVertexAttribPointer(program.aTexCoord, 2, GLES20.GL_FLOAT, false, STRIDE, quad)
        GLES20.glEnableVertexAttribArray(program.aTexCoord)

        GLES20.glUniformMatrix4fv(program.uSTMatrix, 1, false, matrix, 0)
        GLES20.glUniform2f(program.uOffset, offX, offY)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        val target = if (external) GLES11Ext.GL_TEXTURE_EXTERNAL_OES else GLES20.GL_TEXTURE_2D
        GLES20.glBindTexture(target, textureId)
        GLES20.glUniform1i(program.uTexture, 0)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(program.aPosition)
        GLES20.glDisableVertexAttribArray(program.aTexCoord)
    }

    private fun bindTarget(fbo: Int, width: Int, height: Int) {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
        GLES20.glViewport(0, 0, width, height)
    }

    private fun createExternalTexture(): Int {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        val id = ids[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, id)
        GLES20.glTexParameteri(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
            GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR
        )
        GLES20.glTexParameteri(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
            GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR
        )
        GLES20.glTexParameteri(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
            GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE
        )
        GLES20.glTexParameteri(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
            GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE
        )
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, 0)
        return id
    }

    private fun createColorTexture(width: Int, height: Int): Int {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, width, height, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null
        )
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0)
        return ids[0]
    }

    private fun createFramebuffer(textureId: Int): Int {
        val ids = IntArray(1)
        GLES20.glGenFramebuffers(1, ids, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, ids[0])
        GLES20.glFramebufferTexture2D(
            GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
            GLES20.GL_TEXTURE_2D, textureId, 0
        )
        val status = GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER)
        check(status == GLES20.GL_FRAMEBUFFER_COMPLETE) {
            "Framebuffer incomplete: 0x${Integer.toHexString(status)}"
        }
        return ids[0]
    }

    private fun deleteFbos() {
        if (fboA != 0 || fboB != 0) {
            GLES20.glDeleteFramebuffers(2, intArrayOf(fboA, fboB), 0)
        }
        if (texA != 0 || texB != 0) {
            GLES20.glDeleteTextures(2, intArrayOf(texA, texB), 0)
        }
        fboA = 0; fboB = 0; texA = 0; texB = 0
    }

    private fun releaseVideoSurfaceObjects() {
        try {
            surfaceTexture?.setOnFrameAvailableListener(null)
        } catch (e: RuntimeException) {
            // ignore
        }
        try {
            currentSurface?.release()
        } catch (e: RuntimeException) {
            // ignore
        }
        try {
            surfaceTexture?.release()
        } catch (e: RuntimeException) {
            // ignore
        }
        currentSurface = null
        surfaceTexture = null
    }

    private companion object {
        const val FBO_SCALE = 0.5f
        const val STRIDE = 16

        val IDENTITY_MATRIX = floatArrayOf(
            1f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f,
            0f, 0f, 1f, 0f,
            0f, 0f, 0f, 1f
        )

        const val VERTEX_SHADER = """attribute vec4 aPosition;
attribute vec4 aTexCoord;
uniform mat4 uSTMatrix;
varying vec2 vTexCoord;
void main() {
    gl_Position = aPosition;
    vTexCoord = (uSTMatrix * aTexCoord).xy;
}
"""

        // 5-tap 高斯（借双线性插值等效 9-tap），权重和约等于 1
        const val BLUR_FS_OES = """#extension GL_OES_EGL_image_external : require
precision mediump float;
uniform samplerExternalOES uTexture;
uniform vec2 uOffset;
varying vec2 vTexCoord;
void main() {
    vec4 sum = texture2D(uTexture, vTexCoord) * 0.2270270270;
    sum += texture2D(uTexture, vTexCoord + uOffset * 1.3846153846) * 0.3162162162;
    sum += texture2D(uTexture, vTexCoord - uOffset * 1.3846153846) * 0.3162162162;
    sum += texture2D(uTexture, vTexCoord + uOffset * 3.2307692308) * 0.0702702703;
    sum += texture2D(uTexture, vTexCoord - uOffset * 3.2307692308) * 0.0702702703;
    gl_FragColor = sum;
}
"""

        const val BLUR_FS_2D = """precision mediump float;
uniform sampler2D uTexture;
uniform vec2 uOffset;
varying vec2 vTexCoord;
void main() {
    vec4 sum = texture2D(uTexture, vTexCoord) * 0.2270270270;
    sum += texture2D(uTexture, vTexCoord + uOffset * 1.3846153846) * 0.3162162162;
    sum += texture2D(uTexture, vTexCoord - uOffset * 1.3846153846) * 0.3162162162;
    sum += texture2D(uTexture, vTexCoord + uOffset * 3.2307692308) * 0.0702702703;
    sum += texture2D(uTexture, vTexCoord - uOffset * 3.2307692308) * 0.0702702703;
    gl_FragColor = sum;
}
"""

        const val BLIT_FS = """precision mediump float;
uniform sampler2D uTexture;
uniform vec2 uOffset;
varying vec2 vTexCoord;
void main() {
    gl_FragColor = texture2D(uTexture, vTexCoord);
}
"""
    }
}
