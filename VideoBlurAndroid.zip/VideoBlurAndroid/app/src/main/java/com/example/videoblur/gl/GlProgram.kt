package com.example.videoblur.gl

import android.opengl.GLES20

/** 极简 GLSL program 封装：编译、链接、缓存 attribute / uniform location。 */
internal class GlProgram(vertexSource: String, fragmentSource: String) {

    val programId: Int
    val aPosition: Int
    val aTexCoord: Int
    val uSTMatrix: Int
    val uTexture: Int

    /** blit program 不使用该 uniform，location 会是 -1；glUniform* 传 -1 是合法 no-op。 */
    val uOffset: Int

    init {
        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
        programId = GLES20.glCreateProgram()
        GLES20.glAttachShader(programId, vs)
        GLES20.glAttachShader(programId, fs)
        GLES20.glLinkProgram(programId)

        val status = IntArray(1)
        GLES20.glGetProgramiv(programId, GLES20.GL_LINK_STATUS, status, 0)
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
        check(status[0] == GLES20.GL_TRUE) {
            "GL program link failed: ${GLES20.glGetProgramInfoLog(programId)}"
        }

        aPosition = GLES20.glGetAttribLocation(programId, "aPosition")
        aTexCoord = GLES20.glGetAttribLocation(programId, "aTexCoord")
        uSTMatrix = GLES20.glGetUniformLocation(programId, "uSTMatrix")
        uTexture = GLES20.glGetUniformLocation(programId, "uTexture")
        uOffset = GLES20.glGetUniformLocation(programId, "uOffset")
    }

    fun use() = GLES20.glUseProgram(programId)

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] != GLES20.GL_TRUE) {
            val log = GLES20.glGetShaderInfoLog(shader)
            GLES20.glDeleteShader(shader)
            throw IllegalStateException("GL shader compile failed: $log\n$source")
        }
        return shader
    }
}
