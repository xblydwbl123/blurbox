package com.example.videoblur.gl

import android.content.Context
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.view.Surface
import android.view.SurfaceHolder

/** 承载模糊渲染的 GLSurfaceView，同时对外暴露 ExoPlayer 需要的 Surface。 */
class BlurVideoSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    var onSurfaceReady: ((Surface) -> Unit)? = null
    var onSurfaceLost: (() -> Unit)? = null

    private val blurRenderer: BlurRenderer = BlurRenderer(
        glView = this,
        onSurfaceReady = { surface -> onSurfaceReady?.invoke(surface) },
        onSurfaceLost = { onSurfaceLost?.invoke() }
    )

    /** 每次都读实时值，EGL 重建后仍能拿到最新的 Surface。 */
    val currentSurface: Surface?
        get() = blurRenderer.currentSurface

    /** 0 = 原画，默认 8；单位为半分辨率 FBO 的像素。 */
    var blurPixels: Float
        get() = blurRenderer.blurPixels
        set(value) {
            blurRenderer.blurPixels = value
            requestRender()
        }

    /** 高斯迭代轮数，1..4；越大越糊，GPU 开销也越高。 */
    var blurIterations: Int
        get() = blurRenderer.iterations
        set(value) {
            blurRenderer.iterations = value
            requestRender()
        }

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        // 切后台不销毁 EGL context，避免 SurfaceTexture 反复重建
        setPreserveEGLContextOnPause(true)
        setRenderer(blurRenderer)
        // 只在视频新帧到达时绘制，省电
        setRenderMode(RENDERMODE_WHEN_DIRTY)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        onSurfaceLost?.invoke()
        super.surfaceDestroyed(holder)
    }
}
