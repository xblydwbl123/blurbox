// 版本组合：AGP 8.11.1 + Gradle 8.13 + Kotlin 2.2.21 + JDK 17
// AGP 8.x 仍需显式声明 kotlin-android 插件（AGP 9.x 才内置 Kotlin）。
plugins {
    id("com.android.application") version "8.11.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.21" apply false
}
